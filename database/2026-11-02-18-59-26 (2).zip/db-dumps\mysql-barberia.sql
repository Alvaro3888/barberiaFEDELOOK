
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `calificaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calificaciones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `turno_id` bigint unsigned NOT NULL,
  `cliente_id` bigint unsigned NOT NULL,
  `puntuacion` tinyint unsigned NOT NULL,
  `comentario` text COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calificaciones_turno_id_foreign` (`turno_id`),
  KEY `calificaciones_cliente_id_foreign` (`cliente_id`),
  CONSTRAINT `calificaciones_cliente_id_foreign` FOREIGN KEY (`cliente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificaciones_turno_id_foreign` FOREIGN KEY (`turno_id`) REFERENCES `turnos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calificaciones` WRITE;
/*!40000 ALTER TABLE `calificaciones` DISABLE KEYS */;
INSERT INTO `calificaciones` VALUES (1,28,8,5,'excelente atencion y muy rapidos',1,'2026-10-21 16:56:40','2026-10-21 16:56:40'),(2,29,8,4,'excelente, nada mas que decir',1,'2026-10-21 17:34:55','2026-10-21 17:34:55'),(3,31,8,5,'muy rapidos, prueba 2',1,'2026-10-22 12:35:44','2026-11-02 18:58:24'),(4,33,8,5,'buena experiencia en el local',1,'2026-10-22 21:17:05','2026-10-22 21:17:05'),(5,40,19,4,'buen servicio , prueba 3. distinto usuario',1,'2026-10-29 06:10:21','2026-10-29 06:10:21');
/*!40000 ALTER TABLE `calificaciones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `configuracions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `configuracions_clave_unique` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `configuracions` WRITE;
/*!40000 ALTER TABLE `configuracions` DISABLE KEYS */;
INSERT INTO `configuracions` VALUES (1,'whatsapp_numero','543888654557','2026-11-02 20:16:57','2026-11-02 20:44:46'),(2,'whatsapp_mensaje','Hola Fede looK, quiero hacer una consulta sobre un turno.','2026-11-02 20:16:57','2026-11-02 20:16:57'),(3,'instagram_url','https://instagram.com/fedelookbarberia','2026-11-02 20:16:57','2026-11-02 20:16:57'),(4,'facebook_url','https://www.facebook.com/fede.look.2025','2026-11-02 20:16:57','2026-11-02 20:44:46'),(5,'tiktok_url','https://tiktok.com/@fedelookbarberia','2026-11-02 20:16:58','2026-11-02 20:16:58'),(6,'backup_frecuencia','7','2026-11-02 21:53:00','2026-11-02 21:53:00');
/*!40000 ALTER TABLE `configuracions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `imagenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagenes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `referencia_id` bigint unsigned DEFAULT NULL,
  `ruta` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `imagenes` WRITE;
/*!40000 ALTER TABLE `imagenes` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagenes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2026_04_29_172910_create_roles_table',1),(6,'2026_04_29_172922_create_sucursales_table',1),(7,'2026_04_29_172932_create_servicios_table',1),(8,'2026_04_29_173101_create_usuarios_table',1),(9,'2026_04_29_173111_create_turnos_table',1),(10,'2026_04_29_173120_create_pagos_table',1),(11,'2026_04_29_173133_create_movimientos_table',1),(12,'2026_08_30_022456_create_imagenes_table',2),(13,'2026_08_31_171224_add_duracion_to_servicios_table',3),(14,'2026_09_01_043259_add_activo_to_usuarios_table',4),(15,'2026_09_01_061638_add_activo_to_sucursales_table',5),(16,'2026_09_01_063453_add_activo_to_servicios_table',6),(17,'2026_09_08_035215_add_imagen_url_to_servicios_table',7),(18,'2026_09_08_035718_change_imagen_url_length_in_servicios_table',8),(19,'2026_09_08_052357_create_tipos_servicio_table',9),(20,'2026_09_08_053313_add_tipo_servicio_id_to_servicios_table',10),(21,'2026_09_08_060653_add_activo_to_tipos_servicio_table',11),(22,'2026_09_08_170131_add_sucursal_id_to_tipos_servicio_table',12),(23,'2026_10_05_042852_add_mercadopago_fields_to_pagos_table',13),(24,'2026_10_08_013727_add_reprogramaciones_count_to_turnos_table',14),(25,'2026_10_09_222520_add_imagen_and_mapa_to_sucursales_table',15),(26,'2026_10_21_130957_create_calificacions_table',16),(27,'2026_10_23_135858_add_avatar_to_users_table',17),(28,'2026_10_23_145016_add_avatar_to_usuarios_table',18),(29,'2026_10_25_222238_create_turnos_trabajo_table',19),(30,'2026_10_28_032037_add_remember_token_to_usuarios_table',20),(31,'2026_10_30_001104_remove_imagen_url_from_tables',21),(32,'2026_11_01_032520_add_penalization_fields_to_usuarios_table',22),(33,'2026_11_01_032850_add_origen_and_emergency_to_turnos_table',22),(34,'2026_11_02_145940_add_activo_to_calificaciones_table',23),(35,'2026_11_02_171325_create_configuracions_table',24);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `movimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimientos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` bigint unsigned NOT NULL,
  `tipo_accion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `movimientos_usuario_id_foreign` (`usuario_id`),
  CONSTRAINT `movimientos_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `movimientos` WRITE;
/*!40000 ALTER TABLE `movimientos` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimientos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `turno_id` bigint unsigned NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `metodo` enum('efectivo','mercado_pago','otro') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` enum('pendiente','pagado','fallido') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `payment_id_mp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_id_mp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preference_id_mp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merchant_order_id_mp` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pagos_turno_id_foreign` (`turno_id`),
  CONSTRAINT `pagos_turno_id_foreign` FOREIGN KEY (`turno_id`) REFERENCES `turnos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,5,10000.00,'mercado_pago','pagado','2026-09-24 01:26:37','2026-09-24 01:26:37',NULL,NULL,NULL,NULL),(2,7,15000.00,'mercado_pago','pagado','2026-09-28 03:34:28','2026-09-28 03:34:28',NULL,NULL,NULL,NULL),(3,8,15000.00,'mercado_pago','pagado','2026-10-01 19:47:19','2026-10-01 19:47:19',NULL,NULL,NULL,NULL),(4,9,10000.00,'mercado_pago','pagado','2026-10-05 07:21:57','2026-10-05 07:21:57',NULL,NULL,NULL,NULL),(5,10,10000.00,'mercado_pago','pagado','2026-10-05 07:49:46','2026-10-05 07:49:46','182445085396','182445085396','3693016946-de06e7f0-2a8d-4517-ae21-31b9a4d901bb','44987072231'),(6,11,10000.00,'mercado_pago','pagado','2026-10-06 16:10:44','2026-10-06 16:10:44','181690124553','181690124553','3693016946-6f883f6a-b0c2-45d7-b304-3e520bc64b82','45024862413'),(7,12,10000.00,'mercado_pago','pagado','2026-10-06 17:52:05','2026-10-06 17:52:05','182722468874','182722468874','3693016946-36c04609-bb66-45e3-b98e-dd23248a9384','45027789993'),(8,15,11000.00,'efectivo','pagado','2026-10-19 18:13:37','2026-10-19 18:13:37',NULL,NULL,NULL,NULL),(9,16,15000.00,'efectivo','pagado','2026-10-19 19:20:36','2026-10-19 19:20:36',NULL,NULL,NULL,NULL),(10,17,12000.00,'efectivo','pagado','2026-10-19 19:32:35','2026-10-19 19:32:35',NULL,NULL,NULL,NULL),(11,18,12000.00,'efectivo','pagado','2026-10-19 19:43:47','2026-10-19 19:43:47',NULL,NULL,NULL,NULL),(12,19,15000.00,'efectivo','pagado','2026-10-19 19:46:09','2026-10-19 19:46:09',NULL,NULL,NULL,NULL),(13,20,10000.00,'efectivo','pagado','2026-10-19 20:07:49','2026-10-19 20:07:49',NULL,NULL,NULL,NULL),(14,21,15000.00,'efectivo','pagado','2026-10-19 20:40:49','2026-10-19 20:40:49',NULL,NULL,NULL,NULL),(15,22,10000.00,'efectivo','pagado','2026-10-19 22:13:23','2026-10-19 22:13:23',NULL,NULL,NULL,NULL),(16,23,15000.00,'efectivo','pagado','2026-10-19 22:13:52','2026-10-19 22:13:52',NULL,NULL,NULL,NULL),(17,24,10000.00,'efectivo','pagado','2026-10-19 22:14:43','2026-10-19 22:14:43',NULL,NULL,NULL,NULL),(18,25,10000.00,'efectivo','pagado','2026-10-19 22:38:39','2026-10-19 22:38:39',NULL,NULL,NULL,NULL),(19,26,15000.00,'efectivo','pagado','2026-10-20 01:08:14','2026-10-20 01:08:14',NULL,NULL,NULL,NULL),(20,30,10000.00,'mercado_pago','pagado','2026-10-21 05:54:41','2026-10-21 05:54:41','184258901343','184258901343','3693016946-471f46f1-0b36-4a9a-9bf9-120bfffb852c','45428880557'),(21,31,5000.00,'mercado_pago','pagado','2026-10-22 12:22:34','2026-10-22 12:22:34','185507367232','185507367232','3693016946-f35e340f-9315-4075-82dc-2798093a065f','45490737590'),(22,32,12000.00,'efectivo','pagado','2026-10-22 12:42:46','2026-10-22 12:42:46',NULL,NULL,NULL,NULL),(23,33,2.00,'efectivo','pagado','2026-10-22 17:27:02','2026-10-22 17:27:02',NULL,NULL,NULL,NULL),(24,34,10000.00,'mercado_pago','pagado','2026-10-22 18:33:55','2026-10-22 18:33:55','185571265078','185571265078','3693016946-c7976ac1-2759-4ebe-bcbc-091f698b4b2e','45469999891'),(25,35,2.00,'efectivo','pagado','2026-10-22 19:07:39','2026-10-22 19:07:39',NULL,NULL,NULL,NULL),(26,36,12000.00,'efectivo','pagado','2026-10-22 21:12:03','2026-10-22 21:12:03',NULL,NULL,NULL,NULL),(27,37,11002.00,'efectivo','pagado','2026-10-27 06:20:16','2026-10-27 06:20:16',NULL,NULL,NULL,NULL),(28,38,15000.00,'mercado_pago','pagado','2026-10-27 14:59:45','2026-10-27 14:59:45','186345592306','186345592306','3693016946-20b9a5b4-ce26-4a69-b257-9376afb733e9','45624762446'),(29,39,2.00,'efectivo','pagado','2026-10-27 15:42:28','2026-10-27 15:42:28',NULL,NULL,NULL,NULL),(30,40,5002.00,'mercado_pago','pagado','2026-10-29 05:55:56','2026-10-29 05:55:56','186632844634','186632844634','3693016946-c20fb5cb-1429-4f9f-aa6e-e11da9b42330','45638132865'),(31,41,11002.00,'efectivo','pagado','2026-10-29 06:23:29','2026-10-29 06:23:29',NULL,NULL,NULL,NULL),(32,42,21000.00,'efectivo','pagado','2026-10-29 17:55:37','2026-10-29 17:55:37',NULL,NULL,NULL,NULL),(33,43,10000.00,'mercado_pago','pagado','2026-11-01 10:05:10','2026-11-01 10:05:10','186136010337','186136010337','3693016946-1a56758d-7501-494d-8630-de456242ba42','45757955048'),(34,44,12000.00,'mercado_pago','pagado','2026-11-02 04:36:23','2026-11-02 04:36:23','186262432819','186262432819','3693016946-9f2ac0fa-07dd-4c29-a2e9-3f24d746042d','45780140896');
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_nombre_unique` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin',NULL,NULL),(2,'barbero',NULL,NULL),(3,'cliente',NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `servicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `duracion` int NOT NULL,
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `precio_actual` int NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `imagen` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tipo_servicio_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `servicios_tipo_servicio_id_foreign` (`tipo_servicio_id`),
  CONSTRAINT `servicios_tipo_servicio_id_foreign` FOREIGN KEY (`tipo_servicio_id`) REFERENCES `tipos_servicio` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `servicios` WRITE;
/*!40000 ALTER TABLE `servicios` DISABLE KEYS */;
INSERT INTO `servicios` VALUES (7,'Cortes Clasico',40,NULL,2,1,NULL,'2026-09-08 21:00:30','2026-10-10 00:33:42',3),(8,'coloracion',50,NULL,15000,1,'servicios/EXANapGXs4s4WAB1SXqnGz9lJEwuGnHYDclBy1fd.webp','2026-09-26 00:02:11','2026-09-26 00:03:20',5),(9,'perfilado de barba estilo vikingo',30,NULL,11000,1,'servicios/urod6DOAK8iLXuoUeXLSYbKUWfTmqOfAx2XNdCCI.webp','2026-10-01 17:35:52','2026-10-01 17:35:52',4),(10,'corte raro',45,NULL,10000,1,'servicios/Adrj5lKxOhxjIh923s9jXxvbQIWUXsk3pbNWBLWk.webp','2026-10-01 18:38:16','2026-10-01 18:38:16',3),(11,'corte raro 2',45,NULL,10000,1,'servicios/mCjjTAMCLvGyj9jw3IuATHPl1QuiEaALykAKkzNE.webp','2026-10-01 18:38:53','2026-10-01 18:38:53',3),(12,'corte super facha',45,NULL,10000,1,'servicios/E1KmwaD1AATgToLvzhaHgAlPZEvBaz04UdKXcn21.webp','2026-10-01 18:39:32','2026-10-01 18:39:32',3),(13,'color facherito',60,NULL,15000,1,'servicios/gxnehdhgOTPUvgcvB0L9bHo0sM1X8TqbIYxlIqsF.webp','2026-10-01 18:40:13','2026-10-01 18:40:13',5),(14,'barba piola',30,NULL,11000,1,'servicios/zaZNcy8aQ83fieswff5tCsG7nXU4d1vUsXvqqNiT.webp','2026-10-01 18:41:38','2026-10-01 18:41:38',4),(15,'barba militar',35,NULL,15000,1,'servicios/knj3eiaZabhTKwGM5h0op5MCJT0M9BBvUJMo6xYy.webp','2026-10-01 18:42:25','2026-10-01 18:42:25',4),(16,'color LGBT',40,NULL,12000,1,'servicios/Bjd7c6SYh94hLrYDHwFhQ9SJvbsTEydC9Oi7xQoC.webp','2026-10-01 18:43:50','2026-10-01 18:43:50',5),(17,'corte feo',45,NULL,10000,1,NULL,'2026-10-10 00:49:08','2026-10-10 00:52:35',3),(18,'barba gay',30,NULL,8000,0,NULL,'2026-10-21 05:18:28','2026-10-21 05:29:59',4),(19,'cremita en el flequillo jaja',30,NULL,5000,1,NULL,'2026-10-22 07:41:41','2026-10-22 07:41:41',7),(20,'Muller',40,NULL,10000,1,NULL,'2026-10-22 20:28:19','2026-10-22 20:28:19',8),(21,'Mohicano',45,NULL,10000,1,NULL,'2026-10-29 06:42:43','2026-10-29 07:00:11',3);
/*!40000 ALTER TABLE `servicios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sucursales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sucursales` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `horarios` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `imagen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mapa_url` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sucursales` WRITE;
/*!40000 ALTER TABLE `sucursales` DISABLE KEYS */;
INSERT INTO `sucursales` VALUES (5,'FEDELOOK','Frente de la Plaza Manuel Belgrano','3884111111',0,'08:00 a 23:00','2026-09-08 20:27:49','2026-11-02 08:03:44',NULL,'<iframe src=\"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d3638.0695359914807!2d-64.8581009!3d-24.2393466!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x941a592ba764a0ab%3A0x14d6a9a435a61218!2sPoli%20MI%20PLAZA!5e0!3m2!1ses-419!2sar!4v1792560307209!5m2!1ses-419!2sar\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"strict-origin-when-cross-origin\"></iframe>'),(6,'CENTRO','Calle 9 de julio','3884112163',0,'08:00 a 23:00','2026-09-08 20:30:17','2026-11-02 08:03:50',NULL,NULL),(7,'Fede Look','sarmiento esquina mitre','3888654588',1,'lunes a sabados de 09:00 a 22:00','2026-10-10 01:52:08','2026-11-02 08:09:17','sucursales/ywiYXpUV0KK0kDzr358I8uzSGXnJpZNRxNsYIRQF.jpg','<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d564.293696203511!2d-64.8690552657752!3d-24.23182885359586!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x941a5865a043e433%3A0x285113ec386c1bc8!2sSarmiento%20188%2C%20Y4501%20San%20Pedro%20de%20Jujuy%2C%20Jujuy!5e0!3m2!1ses-419!2sar!4v1791598018311!5m2!1ses-419!2sar\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"strict-origin-when-cross-origin\"></iframe>'),(8,'ALvaro reparacion de celulares','barrio Esteban Leach','3888654557',1,'todos los dias de 08:00 hasta las 18:30','2026-10-10 02:36:14','2026-10-10 02:44:20','sucursales/hMjzLaWXdYfmMqlnkX2EY7QzdbtSAjGIWsxmOn5E.png','<iframe src=\"https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d405.274638435583!2d-64.86150646193552!3d-24.23785809822344!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2sar!4v1791599616831!5m2!1ses-419!2sar\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"strict-origin-when-cross-origin\"></iframe>'),(9,'JASTROC','Feria la Estacion','38885376523',0,'15:00 pm hasta las 20:00 pm','2026-10-29 06:35:33','2026-10-29 07:14:37',NULL,'https://maps.app.goo.gl/K9pdEvEHEFYMiBxL7');
/*!40000 ALTER TABLE `sucursales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tipos_servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_servicio` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sucursal_id` bigint unsigned NOT NULL,
  `nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tipos_servicio_sucursal_id_foreign` (`sucursal_id`),
  CONSTRAINT `tipos_servicio_sucursal_id_foreign` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tipos_servicio` WRITE;
/*!40000 ALTER TABLE `tipos_servicio` DISABLE KEYS */;
INSERT INTO `tipos_servicio` VALUES (3,5,'Cortes','-',1,'2026-09-08 20:28:38','2026-09-08 21:01:09'),(4,6,'Barba','-',1,'2026-09-08 21:14:50','2026-09-10 19:00:51'),(5,5,'Coloración','pinto de color el pelo',1,'2026-09-26 00:00:44','2026-09-26 00:00:44'),(6,8,'depilacion de axilas','quitaos los bellos fuertes',0,'2026-10-13 20:41:18','2026-10-21 05:20:15'),(7,6,'hidratacion de cabello','nose, se le pone agua en el pelo supongo jaja',1,'2026-10-22 07:39:23','2026-10-22 07:39:35'),(8,5,'Cortes a Maquina','-',1,'2026-10-22 20:27:02','2026-10-22 20:27:02'),(9,5,'Perfiado de Cejas','perfilado a navaja de cejas',0,'2026-10-27 01:59:39','2026-10-29 06:38:47');
/*!40000 ALTER TABLE `tipos_servicio` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `turno_servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turno_servicio` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `turno_id` bigint unsigned NOT NULL,
  `servicio_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_turno_servicio_turno` (`turno_id`),
  KEY `fk_turno_servicio_servicio` (`servicio_id`),
  CONSTRAINT `fk_turno_servicio_servicio` FOREIGN KEY (`servicio_id`) REFERENCES `servicios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_turno_servicio_turno` FOREIGN KEY (`turno_id`) REFERENCES `turnos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `turno_servicio` WRITE;
/*!40000 ALTER TABLE `turno_servicio` DISABLE KEYS */;
INSERT INTO `turno_servicio` VALUES (1,41,7,NULL,NULL),(2,41,14,NULL,NULL),(3,42,17,NULL,NULL),(4,42,9,NULL,NULL),(5,43,20,NULL,NULL),(6,44,16,NULL,NULL);
/*!40000 ALTER TABLE `turno_servicio` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `turnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turnos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cliente_id` bigint unsigned NOT NULL,
  `cliente_nombre_manual` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `barbero_id` bigint unsigned NOT NULL,
  `servicio_id` bigint unsigned NOT NULL,
  `sucursal_id` bigint unsigned NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `estado` enum('pendiente','confirmado','completado','cancelado') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `origen` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `motivo_cancelacion_emergencia` text COLLATE utf8mb4_unicode_ci,
  `reprogramaciones_count` int unsigned NOT NULL DEFAULT '0',
  `precio_historico` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `turnos_cliente_id_foreign` (`cliente_id`),
  KEY `turnos_barbero_id_foreign` (`barbero_id`),
  KEY `turnos_servicio_id_foreign` (`servicio_id`),
  KEY `turnos_sucursal_id_foreign` (`sucursal_id`),
  CONSTRAINT `turnos_barbero_id_foreign` FOREIGN KEY (`barbero_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `turnos_cliente_id_foreign` FOREIGN KEY (`cliente_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `turnos_servicio_id_foreign` FOREIGN KEY (`servicio_id`) REFERENCES `servicios` (`id`),
  CONSTRAINT `turnos_sucursal_id_foreign` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `turnos` WRITE;
/*!40000 ALTER TABLE `turnos` DISABLE KEYS */;
INSERT INTO `turnos` VALUES (5,8,NULL,9,7,5,'2026-09-25','10:32:00','confirmado','web',NULL,0,10000.00,'2026-09-24 01:26:37','2026-09-24 02:18:12'),(6,8,NULL,9,8,5,'2026-09-29','06:28:00','cancelado','web',NULL,0,15000.00,'2026-09-28 03:31:30','2026-09-28 05:20:26'),(7,8,NULL,9,8,5,'2026-09-29','06:28:00','confirmado','web',NULL,0,15000.00,'2026-09-28 03:34:28','2026-09-28 03:34:28'),(8,8,NULL,9,15,5,'2026-10-01','17:45:00','confirmado','web',NULL,0,15000.00,'2026-10-01 19:47:19','2026-10-01 19:47:19'),(9,8,NULL,9,7,5,'2026-10-23','17:21:00','confirmado','web',NULL,1,10000.00,'2026-10-05 07:21:57','2026-10-21 03:29:39'),(10,8,NULL,9,7,5,'2026-10-13','19:00:00','confirmado','web',NULL,0,10000.00,'2026-10-05 07:49:46','2026-10-05 07:49:46'),(11,8,NULL,9,11,5,'2026-10-10','13:55:00','confirmado','web',NULL,0,10000.00,'2026-10-06 16:10:44','2026-10-06 16:10:44'),(12,8,NULL,10,10,6,'2026-10-13','16:50:00','confirmado','web',NULL,0,10000.00,'2026-10-06 17:52:05','2026-10-06 17:52:05'),(13,14,NULL,9,9,5,'2026-10-21','14:07:00','confirmado','web',NULL,0,11000.00,'2026-10-19 17:01:13','2026-10-19 17:01:13'),(14,16,NULL,9,13,5,'2026-10-21','19:59:00','confirmado','web',NULL,0,15000.00,'2026-10-19 18:00:02','2026-10-19 18:00:02'),(15,16,NULL,9,7,5,'2026-10-22','15:00:00','confirmado','web',NULL,0,2.00,'2026-10-19 18:13:37','2026-10-22 17:25:44'),(16,16,NULL,9,8,5,'2026-10-21','09:00:00','confirmado','web',NULL,0,15000.00,'2026-10-19 19:20:36','2026-10-19 19:20:36'),(17,16,NULL,9,16,5,'2026-10-21','10:00:00','confirmado','web',NULL,0,12000.00,'2026-10-19 19:32:35','2026-10-21 04:06:54'),(18,16,NULL,9,16,5,'2026-10-21','11:00:00','confirmado','web',NULL,0,12000.00,'2026-10-19 19:43:47','2026-10-19 19:43:47'),(19,16,NULL,9,13,5,'2026-10-21','12:00:00','confirmado','web',NULL,0,15000.00,'2026-10-19 19:46:09','2026-10-19 19:46:09'),(20,16,NULL,9,12,5,'2026-10-21','15:00:00','confirmado','web',NULL,0,10000.00,'2026-10-19 20:07:49','2026-10-19 20:07:49'),(21,16,NULL,9,15,5,'2026-10-21','21:00:00','confirmado','web',NULL,0,15000.00,'2026-10-19 20:40:49','2026-10-19 20:40:49'),(22,16,NULL,9,12,5,'2026-10-21','16:00:00','cancelado','web',NULL,0,10000.00,'2026-10-19 22:13:23','2026-10-20 00:59:38'),(23,16,NULL,9,15,5,'2026-10-20','18:30:00','cancelado','web',NULL,0,15000.00,'2026-10-19 22:13:52','2026-10-21 04:42:30'),(24,16,NULL,9,17,5,'2026-10-22','09:30:00','confirmado','web',NULL,0,10000.00,'2026-10-19 22:14:43','2026-10-20 16:45:01'),(25,16,'pompunchinosixseven',12,12,6,'2026-10-22','09:00:00','completado','web',NULL,0,10000.00,'2026-10-19 22:38:39','2026-10-22 12:37:54'),(26,14,NULL,9,13,5,'2026-10-21','16:00:00','confirmado','web',NULL,0,15000.00,'2026-10-20 01:08:14','2026-10-20 01:08:14'),(27,8,NULL,9,12,5,'2026-10-21','08:00:00','cancelado','web',NULL,0,10000.00,'2026-10-21 05:47:58','2026-10-21 05:54:58'),(28,8,NULL,9,12,5,'2026-10-21','08:00:00','completado','web',NULL,0,10000.00,'2026-10-21 05:49:41','2026-10-21 15:14:28'),(29,8,NULL,9,12,5,'2026-10-21','13:00:00','completado','web',NULL,0,10000.00,'2026-10-21 05:51:29','2026-10-21 17:34:14'),(30,8,NULL,9,12,5,'2026-10-21','13:00:00','confirmado','web',NULL,0,10000.00,'2026-10-21 05:54:41','2026-10-21 05:54:41'),(31,8,NULL,9,19,5,'2026-10-22','11:00:00','completado','web',NULL,0,5000.00,'2026-10-22 12:22:34','2026-10-22 12:27:19'),(32,16,'cholo juanito',9,16,5,'2026-10-22','10:15:00','confirmado','web',NULL,0,12000.00,'2026-10-22 12:42:46','2026-10-22 12:42:46'),(33,8,NULL,9,7,5,'2026-10-22','16:30:00','completado','web',NULL,0,2.00,'2026-10-22 17:27:02','2026-10-22 21:10:45'),(34,8,NULL,9,10,5,'2026-10-22','19:30:00','confirmado','web',NULL,0,10000.00,'2026-10-22 18:33:55','2026-10-22 18:33:55'),(35,16,'Francisco Arias',9,7,5,'2026-10-22','20:33:00','confirmado','web',NULL,0,2.00,'2026-10-22 19:07:39','2026-10-22 19:07:39'),(36,16,'Cliente Ocasional',17,16,5,'2026-10-23','08:17:00','confirmado','web',NULL,0,12000.00,'2026-10-22 21:12:03','2026-10-22 21:12:03'),(37,16,'Cliente Ocasional',18,7,5,'2026-10-27','08:00:00','confirmado','web',NULL,0,11002.00,'2026-10-27 06:20:16','2026-10-27 06:20:16'),(38,8,NULL,17,12,5,'2026-10-27','20:45:00','confirmado','web',NULL,0,15000.00,'2026-10-27 14:59:45','2026-10-27 14:59:45'),(39,16,'Cliente Ocasional',17,7,5,'2026-10-27','20:00:00','confirmado','web',NULL,0,2.00,'2026-10-27 15:42:28','2026-10-27 15:42:28'),(40,19,NULL,17,7,5,'2026-10-29','03:00:00','completado','web',NULL,0,5002.00,'2026-10-29 05:55:56','2026-10-29 06:07:11'),(41,16,'poroto',17,7,5,'2026-10-29','17:30:00','confirmado','web',NULL,0,11002.00,'2026-10-29 06:23:29','2026-10-29 17:53:28'),(42,16,'Cliente Ocasional',9,17,5,'2026-10-30','08:00:00','confirmado','web',NULL,0,21000.00,'2026-10-29 17:55:37','2026-10-29 17:55:37'),(43,19,NULL,9,20,5,'2026-11-01','08:37:00','confirmado','web',NULL,2,10000.00,'2026-11-01 10:05:10','2026-11-01 11:31:10'),(44,19,NULL,18,16,5,'2026-11-05','09:00:00','confirmado','web',NULL,2,12000.00,'2026-11-02 04:36:23','2026-11-02 05:01:01');
/*!40000 ALTER TABLE `turnos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `turnos_trabajo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `turnos_trabajo` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_fin` time NOT NULL,
  `incluye_siesta` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `turnos_trabajo` WRITE;
/*!40000 ALTER TABLE `turnos_trabajo` DISABLE KEYS */;
INSERT INTO `turnos_trabajo` VALUES (1,'Turno Mañana','08:00:00','13:30:00',0,'2026-10-26 17:17:19','2026-10-29 05:27:59'),(2,'Turno Tarde','17:30:00','22:00:00',0,'2026-10-26 17:17:19','2026-10-29 05:30:12'),(3,'Horario Corrido','08:00:00','18:00:00',1,'2026-10-26 17:17:19','2026-11-01 09:57:53');
/*!40000 ALTER TABLE `turnos_trabajo` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `ausencias_online_count` int unsigned NOT NULL DEFAULT '0',
  `penalizado_hasta` timestamp NULL DEFAULT NULL,
  `rol_id` bigint unsigned NOT NULL DEFAULT '3',
  `sucursal_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `turno_trabajo_id` bigint unsigned DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuarios_email_unique` (`email`),
  KEY `usuarios_rol_id_foreign` (`rol_id`),
  KEY `usuarios_sucursal_id_foreign` (`sucursal_id`),
  KEY `usuarios_turno_trabajo_id_foreign` (`turno_trabajo_id`),
  CONSTRAINT `usuarios_rol_id_foreign` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `usuarios_sucursal_id_foreign` FOREIGN KEY (`sucursal_id`) REFERENCES `sucursales` (`id`),
  CONSTRAINT `usuarios_turno_trabajo_id_foreign` FOREIGN KEY (`turno_trabajo_id`) REFERENCES `turnos_trabajo` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (7,'Administrador','admin@barberia.com',NULL,'3888654557','$2y$12$ebz/NHdF2T89i9S5YBN31.XsYTIMJReUS9KEExdcxfHKYrhHdoaX2',1,0,NULL,1,5,'2026-09-08 20:24:56','2026-10-28 23:57:34',NULL,NULL),(8,'Alvaro Estrada','alvaro123@gmail.com','avatars/413kSS5LNFAeOeYJMrDqav0v5nsjzwOGIJMemdY0.jpg','3888654580','$2y$12$WE/q6VVLv4URWn9b5Xs21ermFaRYIG58LsqgdsEJf0JGzuUL2RBA6',1,0,NULL,3,NULL,'2026-09-10 19:36:07','2026-10-23 20:16:22',NULL,NULL),(9,'Juan Perez','juan123@gmail.com','avatars/h0Wubxpe7kYIfU0HcgzYIpwrhshbFlS6VxAUfY94.jpg','3888654577','$2y$12$LOFeKqN.7J7jsgN55SK20.sz9fauii6zjPWfeIgPDHtVcHS4EQWXS',1,0,NULL,2,5,'2026-09-10 19:50:43','2026-10-29 04:50:27',1,NULL),(10,'Fede','fede@barbero.com',NULL,'3888232323','$2y$12$1k8pii7hi9NLB6tDXCj1AeaIUMv9u9dZGinaDqZfOsZO9.YtBf9wi',1,0,NULL,2,6,'2026-10-06 17:34:58','2026-10-06 17:34:58',NULL,NULL),(11,'1','1@1',NULL,'1','$2y$12$0j4ZqsFueX8LJOwIP.0Gp.vODB6fU933Md14qWCfdU41Xif6jlosS',1,0,NULL,3,NULL,'2026-10-06 17:44:18','2026-10-06 17:44:18',NULL,NULL),(12,'Alvaro','a@gmail.com',NULL,'388865665657','$2y$12$x5gDlWJQFUAADB4cnIk1IemaXuV.urYoScJSimtOQWfUxIu9c4NuC',1,0,NULL,2,6,'2026-10-13 04:24:52','2026-10-13 04:24:52',NULL,NULL),(14,'pepito','cliente2@gmail.com',NULL,'3888654534','$2y$12$ahSf1BW6M875CHDnD19wNuRKKwV26DatLKfRQ/VEWduwfkE3pb20a',1,0,NULL,3,5,'2026-10-13 06:20:33','2026-10-13 06:20:33',NULL,NULL),(15,'oscar','oscar@gmail.com',NULL,'111111111111111','$2y$12$yzCeAxagXmgwtK9L9dsZ7uuZ3JS1knOaga1nsdgvEEG4lNhPa6JUq',1,0,NULL,3,5,'2026-10-13 17:32:08','2026-10-13 17:32:08',NULL,NULL),(16,'Cliente Ocasional','mostrador@barberia.com',NULL,NULL,'$2y$12$KnJj.Ex.xH.J9o2xVmUHx.TAcj80.qGXi3rXXPBgiqOk5ggagQx2y',1,0,NULL,3,NULL,'2026-10-19 18:00:02','2026-10-19 18:00:02',NULL,NULL),(17,'Jose Noguera','jose@gmail.com','avatars/4zQwvhOoqXoX5ULAea6hmSQf8SuWoHMm3Lpt8aVh.jpg','3888603795','$2y$12$/LhmFzbNSKv41Oahs1S5OOI8wdQ3cVZEvlegavsBifXUPaLmyrkA.',1,0,NULL,2,5,'2026-10-22 21:08:16','2026-10-29 04:53:50',2,NULL),(18,'FEDE PEREZ','fede123@gmail.com','avatars/gOWju8HeDW9rExSJuJeQgDdBpToBjWycFUhbPZta.jpg','3888654323','$2y$12$4cuSWEzUqR/Chf//XjxL/ut3paAy6j8cSN3F4vhQKs0va2WgsdnWO',1,0,NULL,1,5,'2026-10-26 20:19:22','2026-10-29 04:53:17',3,NULL),(19,'Salon Casa','saloncasa780@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocJqBaIt8K1k8TFINUv25-su2wP2ya9W297fxJRog8OHP74odg=s96-c','3888654557','$2y$12$oUYiI9cx62UYR.d5b.HTSu4lVqgOOW0QVX2RdK2HcdSFU00zSsS9G',1,0,NULL,3,5,'2026-10-28 05:25:34','2026-10-29 05:44:55',NULL,'TLtZxojM5ywhFaBH37FVSyXSZljyI43RZCf8VQ0jcpFwDHykRzA0NsKLCniK'),(21,'Alvaro Fernando Estrada','alvaroe780@gmail.com','https://lh3.googleusercontent.com/a/ACg8ocLGTtwL-sWvfy6cclZc1ZFT-o_7gRe-J_ovHnkQuMTb5twG7t4vaA=s96-c',NULL,'$2y$12$npBp94o2gOcEYPiPJulVReTXoIEcKomB6Q.z8YaW9ZBiz1uSJb9Me',1,0,NULL,3,NULL,'2026-10-28 20:40:50','2026-10-29 05:10:41',NULL,NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

